import edu.duke.FileResource;
import java.io.*;
import java.util.*;

public class Edge {
    protected String to;
    protected double weight;
}
